import java.util.*;
/**
 * Created by Cheng Li, Chaoyue Liu, Chi Zhang on 12/8/16.
 */

public enum Type{
    Write,
    Read
}
