namespace java sequenceassign

service SequenceAssign {
    i32 sequenceAssign(),
}